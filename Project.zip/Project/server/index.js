const mysql = require('mysql');
const express = require('express');
const cors = require('cors');
const atob = require('atob');
const jwt = require('jsonwebtoken');
const config = require('config');
const itemRoutesApp = require('./routes/reviews');

const PORT = config.get("port");
const app = express();
app.use(cors());
app.use(express.json());
app.use("/reviews",itemRoutesApp );

app.listen(PORT, ()=>{console.log("Server started listening...")})
