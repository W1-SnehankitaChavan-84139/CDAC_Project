const express = require('express');
const mysql = require('mysql');
const config = require('config');

const app = express.Router();
const connectionDetails = {
                            host: config.get("host"), 
                            database: config.get("database"), 
                            port: config.get("serverport"), 
                            user: config.get("user"), 
                            password:config.get("password")
                           };

app.get("/", (request, response)=>
{
    let queryText = `select * from Reviews`;
    let connection = mysql.createConnection(connectionDetails);
    connection.connect();
    connection.query(queryText, (err, result)=>
    {
        response.setHeader("Content-Type", "application/json");
        if(err==null)
            {
                response.write(JSON.stringify(result));
            }
        else
            {
                response.write(JSON.stringify(err));        
            }
        connection.end();
        response.end();
    })
});
app.post("/", (request, response)=>{

    let Rating = request.body.Rating;
    let Comment= request.body.Comment;
    let CreatedAt = request.body.CreatedAt;

    let queryText = `insert into Reviews(Rating,Comment,CreatedAt) 
			 values('${Rating}', '${Comment}','${CreatedAt}' );`;

    console.log(queryText);

    let connection = mysql.createConnection(connectionDetails);
    connection.connect();
    connection.query(queryText, (err, result)=>
    {        response.setHeader("Content-Type", "application/json");

        if(err==null)
            {
                response.write(JSON.stringify(result));
            }
        else
            {
                response.write(JSON.stringify(err));        
            }
        connection.end();
        response.end();
    })
});
app.put("/:ReviewID", (request, response)=>{
    let Rating = request.body.Rating;
    let Comment = request.body.Comment;
    let CreatedAt = request.body.CreatedAt;

    let queryText = `update Reviews set Rating = '${Rating}', 
                                      Comment= '${Comment}', 
                                      CreatedAt ='${CreatedAt}' where ReviewID=${request.params.ReviewID}`;

    console.log(queryText);
    
    let connection = mysql.createConnection(connectionDetails);
    connection.connect();
    connection.query(queryText, (err, result)=>
    {
        response.setHeader("Content-Type", "application/json");
        if(err==null)
            {
                response.write(JSON.stringify(result));
            }
        else
            {
                response.write(JSON.stringify(err));        
            }
        connection.end();
        response.end();
    })
});
app.delete("/:ReviewID", (request, response)=>{

    let queryText = `delete from Reviews where ReviewID=${request.params.ReviewID}`;

    console.log(queryText);
    
    let connection = mysql.createConnection(connectionDetails);
    connection.connect();
    connection.query(queryText, (err, result)=>
    {
        response.setHeader("Content-Type", "application/json");
        if(err==null)
            {
                response.write(JSON.stringify(result));
            }
        else
            {
                response.write(JSON.stringify(err));        
            }
        connection.end();
        response.end();
    })    

});


module.exports = app;