import axios from 'axios';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './common.css';

import { useEffect, useState } from 'react';

function Dashboard() 
{
   // const baseImageUrl = `http://localhost:3000/images/`; //this is for referring images
    const baseAPIUrl = `http://localhost:9999/reviews`;   //this is for referring Web API

    <hr></hr>
    const [reviews, setReviews ] = useState([]);
    const [review, setReview] = useState({"ReviewID":0,
                                      "PackageID":"",
                                      "UserID":0,
                                      "Rating":"",
                                      "Comment":"",
                                       "CreatedAt":""
                                     });

    const getReviews = ()=>{
        axios.get(baseAPIUrl).then((result)=>{
            setReviews(result.data)
        })
    }

    const onTextChange=(args)=>{
        var copyOfReview = {...review};
        copyOfReview[args.target.name] = args.target.value ;
        setReview(copyOfReview);
    }

    const clearTextBoxes = ()=>{
        setReview({"ReviewID":0,
                 "PackageID":"",
                 "UserID":0,
                 "Rating":"",
                 "Comment":"",
                 "CreatedAt":""});
    }

    const editReview =(ReviewID)=>
    {
        for(let i = 0; i < reviews.length; i++)
            {
                if(reviews[i].ReviewID === ReviewID)
                    {
                        var copyOfReview = {...reviews[i]};
                        setReview(copyOfReview);
                        break;
                    }
            }
    }

    const removeReview =(ReviewID)=>{
        let url = baseAPIUrl + "/" + ReviewID;

        axios.delete(url).then((result)=>
            {
            if(result.data.affectedRows!==undefined &&
                result.data.affectedRows > 0)
                {
                    getReviews();
                    clearTextBoxes();
                }
                else
                {
                    alert("something went wrong!")
                    clearTextBoxes();
                }
        })
    }

    const addReview= ()=>{
        axios.post(baseAPIUrl,review).then((result)=>{
            if(result.data.affectedRows!==undefined &&
                result.data.affectedRows > 0)
                {
                    getReviews();
                    clearTextBoxes();
                }
                else
                {
                    alert("something went wrong!")
                    clearTextBoxes();
                }
        })
    }

    const updateReview = ()=>{
        let url = baseAPIUrl + "/" + review.ReviewID;

        axios.put(url,review).then((result)=>{
            if(result.data.affectedRows!==undefined &&
                result.data.affectedRows > 0)
                {
                    getReviews();
                    clearTextBoxes();
                }
                else
                {
                    alert("something went wrong!")
                    clearTextBoxes();
                }
        })
    }

    useEffect(()=>{
        getReviews();

    }, []) //this code is like component did mount

    debugger;
    return (<>
            <div className='row' style={{margin: 50}}>
                   <div>
                        <input type='hidden' name='ReviewID' 
                                             value={review.ReviewID}/>

                        <h3>PackageID</h3>
                        <input type='text' className='form-control'
                                           name='PackageID'
                                           value={review.PackageID}
                                           onChange={onTextChange}/>

                        <h3>UserID</h3>
                        <input type='number' className='form-control'
                                           name='UserID'
                                           value={review.UserID}
                                           onChange={onTextChange}/>

                        <h3>Rating</h3>
                        <input type='text' className='form-control'
                                           name='Rating'
                                           value={review.Rating}
                                           onChange={onTextChange}/>
                        <hr></hr>

                        <h3>Comment</h3>
                        <input type='text' className='form-control'
                                           name='Comment'
                                           value={review.Comment}
                                           onChange={onTextChange}/>
                        <hr></hr>

                        <h3>CreatedAt</h3>
                        <input type='text' className='form-control'
                                           name='CreatedAt'
                                           value={review.CreatedAt}
                                           onChange={onTextChange}/>
                        <hr></hr>
                        <button className='btn btn-primary'
                                onClick={addReview}>
                            Add Review
                        </button>
                        {" "}
                         <button className='btn btn-primary'
                                onClick={updateReview}>
                            Update Review
                        </button>
                   </div>
            </div>
            
            <hr></hr>
            
            <div className='row' style={{margin: 50}}>
                {
                    reviews.map(review=>
                    {

                        return <div key={review.ReviewID} className='col-md-3 itemDiv'
                                    style={{margin: 5}}>
                                   <center>
                                     {/* <img className='img-responsive'
                                         style={{margin: 5}} alt={review.PackageID}
                                         src={baseImageUrl + review.ReviewImage}/> */}
                                    <hr></hr>
                                    <h3>PackageID: {review.PackageID}</h3>
                                    <h4>UserID: {review.UserID}</h4>
                                    <h3>Rating: {review.Rating}</h3>
                                    <h4>Comment: {review.Comment}</h4>
                                    <h4>CreatedAt: {review.CreatedAt}</h4>
                                    <hr></hr>
                                    <button className='btn btn-warning'
                                            onClick={()=>
                                            {
                                                  editReview(review.ReviewID);
                                            }}>
                                        Edit Review
                                    </button> 
                                    
                                    {" "}
                                    
                                    <button className='btn btn-danger'
                                            onClick={()=>
                                            {
                                               removeReview(review.ReviewID);
                                            }}>
                                        Remove Review
                                    </button>
                                   </center>
                               </div>
                    })
                }
            </div>
            
            </>);
}

export default Dashboard;